from retrain_model import retrain_model

if __name__ == '__main__':
    retrain_model()
